module qkmtwo.invmgmtsys {
    requires javafx.controls;
    requires javafx.fxml;


    opens qkmtwo.invmgmtsys to javafx.fxml;
    exports qkmtwo.invmgmtsys;
}